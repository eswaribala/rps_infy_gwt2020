package com.loiane.gxt3.client;


import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.sencha.gxt.widget.core.client.Composite;
import com.sencha.gxt.widget.core.client.Window;
import com.sencha.gxt.widget.core.client.button.TextButton;
import com.sencha.gxt.widget.core.client.container.VerticalLayoutContainer;
import com.sencha.gxt.widget.core.client.event.SelectEvent;
import com.sencha.gxt.widget.core.client.event.SubmitCompleteEvent;
import com.sencha.gxt.widget.core.client.event.SubmitCompleteEvent.SubmitCompleteHandler;
import com.sencha.gxt.widget.core.client.form.FieldLabel;
import com.sencha.gxt.widget.core.client.form.FileUploadField;
import com.sencha.gxt.widget.core.client.form.FormPanel;
import com.sencha.gxt.widget.core.client.form.FormPanel.Encoding;
import com.sencha.gxt.widget.core.client.form.FormPanel.Method;
import com.sencha.gxt.widget.core.client.info.Info;

public class FormDemo extends Composite {
	
	
	public FormDemo()
	{
		final FormPanel formPanel = new FormPanel();

		  FileUploadField fileUploadField = new FileUploadField();
		  fileUploadField.setName("fileUploadField");

		  VerticalLayoutContainer vertLayoutCont = new VerticalLayoutContainer();
		  vertLayoutCont.add(new FieldLabel(fileUploadField, "File"));
		  vertLayoutCont.add(new TextButton("OK"));
				  

		  formPanel.setMethod(Method.POST);
		  formPanel.setEncoding(Encoding.MULTIPART);
		  formPanel.setAction("http://www.example.com/my_upload_url");
		  formPanel.setWidget(vertLayoutCont);
		  formPanel.addSubmitCompleteHandler(new SubmitCompleteHandler() {
		    public void onSubmitComplete(SubmitCompleteEvent event) {
		      String resultHtml = event.getResults();
		      Info.display("Upload Response", resultHtml);
		    }
		  });

		  Window window = new Window();
		  window.setHeading("Upload File");
		  window.setPixelSize(300, 100);
		  window.setWidget(formPanel);
		  window.show();
	}

}
