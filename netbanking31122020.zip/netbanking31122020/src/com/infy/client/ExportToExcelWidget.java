package com.infy.client;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.Hidden;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
//import com.infy.client.models.Photo;
import com.infy.client.models.Photo;

public class ExportToExcelWidget extends Composite{
	
	public static List<Photo> photos=null;
	
	
	
	public ExportToExcelWidget()
	{	
		photos=ExportListToExcelBuilder.sendData();
		//Window.alert("Calling widget");
		VerticalPanel verticalPanel=new VerticalPanel();		
	    final FormPanel form = new FormPanel();
	    form.setAction(GWT.getModuleBaseURL()+"exportexcel");
	    form.setMethod(FormPanel.METHOD_POST);  
	    String data=null;
	    for(int i=0;i<photos.size();i++)
	    {
	    	
	    	if(i<1000)
	    	 data=data+","+photos.get(i).getTitle()+","+photos.get(i).getId()+"\n";
	    }
	    
		final Hidden excelContentHidden = new Hidden("photoData",data);
		verticalPanel.add(excelContentHidden );
		final Hidden fileNameHidden = new Hidden("fileName", "export");
		verticalPanel.add(fileNameHidden);
		
		Button submitButton=new Button();
		submitButton.setText("Send to Excel");	
		
		verticalPanel.add(submitButton);
		 	
		 submitButton.addClickHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				
				form.submit();
				
			}			
		});
		 
		form.setWidget(verticalPanel);
		initWidget(form);
	}
	

}
