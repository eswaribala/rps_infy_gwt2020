package com.infy.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;
import com.google.web.bindery.autobean.shared.AutoBean;
import com.google.web.bindery.autobean.shared.AutoBeanCodex;
import com.infy.client.models.Customer;
import com.infy.client.models.CustomerFacade;
import com.infy.client.models.CustomerMapper;
import com.infy.client.models.Photo;

public class RegistrationPopup extends DialogBox {
	 private static final Binder binder = GWT.create(Binder.class);
	 interface Binder extends UiBinder<Widget, RegistrationPopup> {
	    }

		//CustomerFactory factory = GWT.create(CustomerFactory.class);
	 CustomerMapper mapper = GWT.create( CustomerMapper.class );
	 
	public RegistrationPopup(String response)
	{
		
		//AutoBean<CustomerFacade> bean = AutoBeanCodex
       //         .decode(factory,CustomerFacade.class, response);
		 
		 Customer customer= mapper.read( response );
		 setWidget(binder.createAndBindUi(this));
	        setAutoHideEnabled(true);
	       setText(customer.getId());
	       // setGlassEnabled(true);
	         //center();
	        setPopupPosition(500, 150);
	        //this.setSize("800px", "400px");
	        this.setWidth("400px");
	       // Label responseLbl=new Label();
	        //responseLbl.setText(response);
	        //FlowPanel flowPanel=new FlowPanel();
	       // flowPanel.add(responseLbl);
	        //this.add(responseLbl);
	}
	
}
