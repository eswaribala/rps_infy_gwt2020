package com.infy.client;

import java.util.List;

import com.google.gwt.user.client.Window;
import com.infy.client.models.Photo;

public class ExportListToExcelBuilder {

	private static List<Photo> data;
	
	public static void getData(List<Photo> photoList)
	{
		
		
		data=photoList;
	}
	
	
	public static List<Photo> sendData()
	{
		return data;
	}
	
}
