package com.infy.client.models;

import java.util.List;

public interface CustomerFacade {
	
	public String getId();
	public void setId(String id); 
	public long getCustomerId();
	public void setCustomerId(long customerId);
	public String getName();
	public void setName(String name);
	public String getEmail();
	public void setEmail(String email);	
	public List<AccountFacade> getAccounts();
	public void setAccounts(List<AccountFacade> accounts);
	public String getDob();
	public void setDob(String dob);

}
