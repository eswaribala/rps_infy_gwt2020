package com.infy.client.models;

public interface AccountFacade {

	public long getAccountNo();
	public void setAccountNo(long accountNo);
	public long getBalance();
	public void setBalance(long balance);
	public String getAccount_Type();
	public void setAccount_Type(String account_Type);
}
