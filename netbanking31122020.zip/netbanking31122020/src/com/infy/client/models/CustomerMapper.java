package com.infy.client.models;

import com.github.nmorel.gwtjackson.client.ObjectMapper;

public interface CustomerMapper extends ObjectMapper<Customer>{

}
