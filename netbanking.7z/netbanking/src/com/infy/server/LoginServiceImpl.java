package com.infy.server;

import com.google.gson.Gson;
import com.google.gwt.core.client.GWT;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.infy.client.LoginService;

public class LoginServiceImpl extends RemoteServiceServlet  implements LoginService {

	@Override
	public boolean validateCredentials(String customerId, String password) {
		// TODO Auto-generated method stub
		boolean status=false;
		 
				
		if(customerId.equals("admin") && (password.equals("admin")))
			status=true;
		return status;
	}

}
