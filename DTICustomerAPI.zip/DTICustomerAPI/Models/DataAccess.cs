﻿using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DTICustomerAPI.Models
{
    public class DataAccess
    {
        MongoClient _client;
        MongoServer _server;
        MongoDatabase _db;

        [Obsolete]
        public DataAccess()
        {
            _client = new MongoClient("mongodb://localhost:27017");
            _server = _client.GetServer();
            _db = _server.GetDatabase("BankDB2020");

            
        }

        public IEnumerable<DTICustomer> GetCustomers()
        {
            return _db.GetCollection<DTICustomer>("DTICustomers").FindAll();
        }


        public DTICustomer GetCustomer(String id)
        {
            var res = Query<DTICustomer>.EQ(p => p.Id, id);
            return _db.GetCollection<DTICustomer>("DTICustomers").FindOne(res);
        }

        public DTICustomer Create(DTICustomer customer)
        {
            _db.GetCollection<DTICustomer>("DTICustomers").Save(customer);
            return customer;
        }

    }
}
