﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DTICustomerAPI.Models
{
    public class DTICustomer
    {



        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public String Id { get; set; }

        [BsonElement]
        public long CustomerId { get; set; }
        [BsonElement]
        public string Name { get; set; }
        [BsonElement]
        public String Dob { get; set; }
        [BsonElement]
        public string Email { get; set; }
        [BsonElement]
        public ICollection<Account> Accounts { get; set; }

    }
}
